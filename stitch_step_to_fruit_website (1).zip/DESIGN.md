---
name: Organic Vitality
colors:
  surface: '#fbf9f1'
  surface-dim: '#dcdad2'
  surface-bright: '#fbf9f1'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f4ec'
  surface-container: '#f0eee6'
  surface-container-high: '#eae8e0'
  surface-container-highest: '#e4e3db'
  on-surface: '#1b1c17'
  on-surface-variant: '#404943'
  inverse-surface: '#30312c'
  inverse-on-surface: '#f3f1e9'
  outline: '#707973'
  outline-variant: '#bfc9c1'
  surface-tint: '#2c694e'
  primary: '#0f5238'
  on-primary: '#ffffff'
  primary-container: '#2d6a4f'
  on-primary-container: '#a8e7c5'
  inverse-primary: '#95d4b3'
  secondary: '#9e4300'
  on-secondary: '#ffffff'
  secondary-container: '#fe8946'
  on-secondary-container: '#6a2a00'
  tertiary: '#0d5237'
  on-tertiary: '#ffffff'
  tertiary-container: '#2c6a4e'
  on-tertiary-container: '#a7e7c4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b1f0ce'
  primary-fixed-dim: '#95d4b3'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#0e5138'
  secondary-fixed: '#ffdbcb'
  secondary-fixed-dim: '#ffb691'
  on-secondary-fixed: '#341100'
  on-secondary-fixed-variant: '#793100'
  tertiary-fixed: '#b0f1cc'
  tertiary-fixed-dim: '#94d4b1'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#0c5136'
  background: '#fbf9f1'
  on-background: '#1b1c17'
  surface-variant: '#e4e3db'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 80px
  max-width: 1280px
---

## Brand & Style

The brand personality is vibrant, nourishing, and optimistic. It aims to bridge the gap between farm-fresh authenticity and modern digital convenience. The target audience includes health-conscious professionals and families who value quality, transparency, and the sensory joy of organic produce.

The design style is **Modern Organic**. It blends the structural clarity of a corporate SaaS with the warmth of high-end editorial layouts. By utilizing a "cream-based" canvas rather than pure white, the UI feels more natural and less clinical. The interface relies on lush photography, generous whitespace, and soft, tactile elements to evoke a sense of abundance and freshness.

## Colors

The palette is inspired by a thriving orchard at dawn. 

- **Primary Green (#2d6a4f):** Used for structural grounding. It provides the "earth" for the design, applied to navigation bars, footers, and primary headings to establish authority and trust.
- **Accent Orange (#f4813f):** The "zest." This high-energy color is reserved exclusively for conversion points, pricing, and active states to guide the eye toward action.
- **Light Green (#95d5b2):** Used for subtle backgrounds, success states, and secondary iconography to maintain the monochromatic depth of the green theme without the weight of the primary shade.
- **Background Cream (#fffdf5):** The foundation. This off-white provides a soft, premium feel that reduces eye strain and makes the vibrant colors of fruit photography pop.
- **Card White (#ffffff):** Used for elevated containers to create a distinct visual lift from the cream background.

## Typography

The typography strategy pairs the elegance of a classic serif with the efficiency of a modern geometric sans-serif.

**Playfair Display** is used for all major headlines. Its high stroke contrast and stylish apertures reflect the premium nature of organic products. For mobile, headline sizes are scaled down aggressively to ensure readability and prevent awkward text wrapping.

**Plus Jakarta Sans** is the workhorse for all functional text. It was chosen for its slightly wider apertures and friendly, open character, which maintains legibility even at small sizes in product descriptions or delivery trackers.

## Layout & Spacing

The system uses a **fluid-to-fixed grid** hybrid. 
- **Mobile:** A 4-column grid with 16px side margins and 16px gutters.
- **Tablet:** An 8-column grid with 32px side margins and 20px gutters.
- **Desktop:** A 12-column grid capped at a max-width of 1280px to preserve line length for readability, with 24px gutters.

Spacing follows a 4px baseline, but defaults to 8px increments for larger component relationships to maintain an "airy" feel. Vertical rhythm is prioritized, using `xl` (48px) spacing between major sections to emphasize the fresh, uncrowded brand aesthetic.

## Elevation & Depth

This design system uses **Tonal Layering** combined with **Ambient Shadows** to create a natural, sunlit depth.

- **Level 0 (Base):** Background Cream (#fffdf5).
- **Level 1 (Cards):** Card White (#ffffff) with a soft, diffused shadow. Shadows should use a hint of the primary green in the tint (e.g., `rgba(45, 106, 79, 0.08)`) with a high blur radius (20px+) and low vertical offset to mimic natural overhead light.
- **Level 2 (Interaction):** Hover states for cards increase the shadow spread and slightly lift the element (Y-offset -4px), creating a tactile "pick-up" sensation.

Outlines are avoided in favor of subtle shadow-based boundaries to keep the UI feeling soft and organic rather than rigid and technical.

## Shapes

The shape language is defined by **rounded, approachable geometry**. 

Standard elements like input fields, small buttons, and tags utilize a 0.5rem (8px) radius. Larger interactive elements, such as product cards and call-to-action banners, use a 1rem (16px) radius to emphasize a friendly, "squishy" tactile quality.

Icons should feature rounded terminals and avoid sharp 90-degree angles to align with the soft-serif typography and the natural curves found in fruit.

## Components

### Buttons
- **Primary:** Background Accent Orange (#f4813f), text White. Bold weight.
- **Secondary:** Background Light Green (#95d5b2), text Primary Green (#2d6a4f).
- **Ghost:** No background, Primary Green border and text.

### Cards
Product cards should have a Card White (#ffffff) background with a 1rem corner radius. Imagery should be top-aligned with no padding (full-bleed) to let the fruit colors dominate the visual space. Information below the image should be padded with `lg` (24px) spacing.

### Inputs & Selects
Use the Background Cream (#fffdf5) for the fill, but ensure a 1px border of Light Green (#95d5b2) to provide definition on white surfaces. Focus states should transition the border to Primary Green.

### Chips/Badges
Use for "In Season," "Organic," or "New" labels. These should have pill-shaped rounding (3rem) and use the Light Green background with dark green text for high legibility.

### Selection Controls
Checkboxes and radio buttons use the Primary Green for the active state, providing a strong "natural/earthy" confirmation.